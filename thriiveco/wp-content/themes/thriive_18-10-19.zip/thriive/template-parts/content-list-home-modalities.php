<div class="col-12 mt-4 p-0">
	<div class="healer-circle">
		<div class="inner-healer-circle">
			<a href="<?php echo $link; ?>">							
				<img src="<?php echo $img_id; ?>"/><?php //echo wp_get_attachment_image($img_id, 'thumbnail'); ?>			
			</a>
		</div>
	</div>
	<div class="txt-wrap mt-3">
		<h5>
			<a href="<?php echo $link; ?>"><?php echo $title; ?></a>
		</h5>
	</div>
</div>