			<div class="col-12 col-sm-12 blog-wrapper text-center mt-5 pb-5">
				<div class="blog-banner">
					<img src="<?php echo get_stylesheet_directory_uri() ?>/assets/images/blog-list-img1.jpg" alt="">
				</div>
				<div class="category-name "><span class="icon-new-cure blog-icon-set"> </span> <span class="text-highlight">Cure</span></div>
				<div class="blog-title mt-3"><h3>The Art Of Dying - Part 2</h3></div>
				<div class="blog-author"><p class="text-highlight">By Newton Kondaveti</p></div>
				<div class="col-12  p-0 d-flex blog-list-details">
					<div class="col-6"><span class="icon-new-calender_1 icon-event"></span> <span>12 Oct, 2018</span> </div>
					<div class="col"><span class="icon-new-comment icon-event"></span>21</div>
					<div class="col"><span class="icon-new-view-eye icon-event"></span>89</div>
				</div>
				<div class="col-12 mt-3 text-left">
					<p>What is Sacred Sexuality? How can we experience it? What role does it play in our spiritual practice?  Cyntha Gonzalez, a trans-</p>
				</div>
				
				<a href="" class="btn btn-primary"> READ </a>
			</div>