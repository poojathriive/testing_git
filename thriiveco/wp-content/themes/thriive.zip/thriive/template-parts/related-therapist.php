<div class="col-6 mt-4">
	<div class="healer-circle">
		<div class="inner-healer-circle">
			<img src="<?php echo get_stylesheet_directory_uri()?>/assets/images/ProfileImage-THR2144352-150x150.jpg" alt="">
		</div>
	</div>
	<div class="txt-wrap mt-3">
		<h3>Sharmila Dhobale</h3>
		<p class="text-highlight mb-0">PLR Therapist</p>
		<p>1. I am passionate about the work…</p>
		<a href="<?php echo get_site_url() ?>/therapist/sharmila-dhobale/" class="btn btn-primary">KNOW MORE</a>
	</div>
</div>

<div class="col-6 mt-4">
	<div class="healer-circle">
		<div class="inner-healer-circle">
			<img src="<?php echo get_stylesheet_directory_uri()?>/assets/images/ProfileImage-THR7729496-150x150.jpg" alt="">
		</div>
	</div>
	<div class="txt-wrap mt-3">
		<h3>Hitesh Vashishth</h3>
		<p class="text-highlight mb-0">Nutritionist</p>
		<p>A Management Professional </p>
		<a href="<?php echo get_site_url() ?>/therapist/hitesh-vashishth/" class="btn btn-primary">KNOW MORE</a>
	</div>
</div>

