<?php
	

add_action('wp_ajax_fetch_my_operator_user', 'fetch_my_operator_user');
add_action('wp_ajax_add_my_operator_user', 'add_my_operator_user');
