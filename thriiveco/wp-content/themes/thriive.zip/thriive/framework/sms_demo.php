<?php
	echo file_get_contents("http://ems.startenterprise.com:8080/bulksms/bulksms?username=THRIIVEOTP&password=SkaeXmPn&type=0&dlr=1&source=THRIIV&destination=8898539142&message=user_form_handler");

?>