=== Media Explorer ===
Contributors: Automattic, johnbillion, garhdez, djpaul
Tags: media, social media, twitter, youtube, media explorer
Stable tag: 1.2

Insert social media content into your posts.

== Description ==
A new media curation tool that lets you add trending content from Twitter and YouTube without ever leaving your post editor!

== Upgrade notice ==

= 1.2 (Sep. 3, 2013 ) =
* We've found where the pagination button for the Twitter service was hiding! You can now "get more" results for the same Twitter search. [29]
* Added a readme for the WordPress plugin, and the Github repo. [32]
* Twitter re-tweets have been hidden from search results. [40]

= 1.1 (Aug. ?, 2013) =
* Unreleased internal version.

= 1.0 (Aug. 28, 2013) =
* First stable release
